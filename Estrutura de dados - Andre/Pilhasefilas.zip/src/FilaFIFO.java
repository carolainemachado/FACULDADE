/*
São estruturas de dados do tipo FIFO (first-in first-out),
onde o primeiro elemento a ser inserido, será o primeiro a ser retirado, ou seja,
adiciona-se itens no fim e remove-se do início.
 */
public class FilaFIFO {
    No inicio;
    No fim;
    int tamanho;
    String info;

    public void inserirFim(){
        No no = new No();
        no.info = info;
        no.proximo = null;
        no.anterior = fim;
        if (fim !=null){
            fim.proximo = no;
        }
        fim = no;
        if (tamanho == 0){
            inicio = fim;
        }
        tamanho ++;
    }

    public String retirarInicio(){
        if (inicio == null){
            return null;
        }
        String out = inicio.info;
        inicio = inicio.proximo;
        if (inicio != null) {
            inicio.anterior = null;
        }else{
            fim = null;
        }
        tamanho --;
        return out;
    }
}
