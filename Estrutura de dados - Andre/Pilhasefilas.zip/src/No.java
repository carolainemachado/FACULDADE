import java.util.Scanner;
public class No {
        String info;
        //ponteiro para o proximo no = um link para o outro no
        No proximo;
        No anterior;
    }

