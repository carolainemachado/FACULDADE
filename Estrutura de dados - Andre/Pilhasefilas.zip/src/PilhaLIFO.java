/*
São estruturas de dados do tipo LIFO (last-in first-out),
onde o último elemento a ser inserido, será o primeiro a ser retirado.
Assim, uma pilha permite acesso a apenas um item de dados - o último inserido.
Para processar o penúltimo item inserido, deve-se remover o último.
 */
public class PilhaLIFO {
    No inicio;
    No fim;
    int tamanho;
    String info;

        public void inserirFim(int numero) {
        No no = new No();
        no.info = info;
        no.proximo = null;
        no.anterior = fim;
        if (fim != null) {
            fim.proximo = no;
        }
        fim = no;
        if (tamanho == 0) {
            inicio = fim;
        }
        tamanho++;
    }

    public String retirarFim() {
        if (fim == null) {
            return null;
        }
        String out = fim.info;
        fim = fim.anterior;
        if (fim != null) {
            fim.proximo = null;
        } else {
            inicio = null;
        }
        tamanho--;
        return out;
    }

    }


