import java.util.Scanner;
public class MenueInteracao{

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in); // para receber valores do teclado

        // criaçao de vetores / 20= quantas posiçoes vai ter o vetor
        int ClassePilha[] = new int[20], menu = 0,numero=0;
        PilhaLIFO pilha = new PilhaLIFO();
        FilaFIFO fifo = new FilaFIFO();

        do {
            System.out.println("-------------MENU-------------");
            System.out.println("PILHA");
            System.out.println("1- Inserir Fim");
            System.out.println("2- Retirar Fim");
            System.out.println("FILA");
            System.out.println("3- Inserir Fim");
            System.out.println("4- Retirar Inicio");
            System.out.println("0- Sair do programa");

            System.out.println("-------------------------------");
            menu = teclado.nextInt();

            if (menu == 1) {
                pilha.inserirFim(numero);
            }
            if (menu == 2) {
                pilha.retirarFim();
            }
            if (menu == 3) {
                fifo.inserirFim();
            }
            if (menu == 4) {
                fifo.retirarInicio();
            }

        } while (menu != 0);
        System.out.println("Voce saiu do programa");

        if (menu == 1) {
            System.out.println("Inserir o fim");
            numero = teclado.nextInt();
            pilha.inserirFim(numero);

        } else if (menu == 2) {
            pilha.retirarFim();
        }

           public static void main (String[]args){
                MenueInteracao m = new MenueInteracao();
                System.out.println(m);

                for (int i = 0; i < 6; i++) {
                    m.inserirFim("" + (char) (i + 97));
                    System.out.println(m);
                }
                m.retirarFim(2, "x");
                System.out.println(m);

            }

        }

   }





