/*import ListaDupla.ListaDupla;

import java.util.Scanner;
//class Main {
    public class outraforma {

    public static void main (String [] args) {
            Scanner teclado = new Scanner(System.in); // para receber valores do teclado

            int menu = 0;
            FilaFIFO fifo = new FilaFIFO();
            int PilhaLIFO;
            PilhaLIFO vetor = new PilhaLIFO(20);
            do {
                System.out.println("-------------MENU-------------");
                System.out.println("PILHA");
                System.out.println("1- Inserir Fim");
                System.out.println("2- Retirar Fim");
                System.out.println("FILA");
                System.out.println("3- Inserir Fim");
                System.out.println("4- Retirar Inicio");
                System.out.println("0- Sair do programa");

                System.out.println("-------------------------------");
                menu = teclado.nextInt();

                if (menu == 1) {
                    vetor.inserirFim();
                }
                // if (menu == 2) {
                //   pilha.retirarFim();
                //}
                if (menu == 3) {
                    fifo.inserirFim();
                }
                if (menu == 4) {
                    fifo.retirarInicio();
                }

            } while (menu != 0);
            System.out.println("Voce saiu do programa");
        }
    }

    class PilhaLIFO {
        Scanner teclado = new Scanner(System.in);

        public PilhaLIFO(int tamanho) {
            int[] vetor = new int[tamanho];
            //pilha = new int[tamanho];
            this.tamanho = tamanho;
        }

        // ATRIBUTOS
        int tamanho;
        int veotor[];
        No inicio;
        No fim;
        String info;

        // METODOS
        // 1 METODO
        public void inserirFim() {
           // System.out.println("2- Insira valor no final ");
            No no = new No();
            no.info = info;
            no.proximo = null;
            no.anterior = fim;
            if (fim != null) {
                fim.proximo = no;
            }
            fim = no;
            if (tamanho == 0) {
                inicio = fim;
            }
            tamanho++;
           // System.out.println("VALOR INSERIDO COM SUCESSO");
        }

    }*/


