import java.util.Arrays;

    public class MetodoBolha {
        public static void main(String[] args) {

            int [] vetor = {3,30,59,60,2,78,4,12};
            bolha (vetor);

            System.out.println(Arrays.toString(vetor));
        }
        public static void bolha(int [] vetor) {
            // responsavel por controlar os elementos que vai ser empurados para ultima posiçao
            for (int ultimo = vetor.length - 1; ultimo >0; ultimo --) {
                for (int i = 0; i < ultimo; i++)
                    if (vetor[i] >vetor[i+1])
                        trocar(vetor,i,i+1);
            }
        }

        private static void trocar(int[] vetor, int i, int j) {
            int aux= vetor[i];
            vetor[i] = vetor[j];
            vetor[j] = aux;
        }
    }


