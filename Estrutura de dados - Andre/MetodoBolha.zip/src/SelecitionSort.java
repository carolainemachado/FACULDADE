import java.util.Arrays;
import java.util.Random;

public class SelecitionSort {
    public static void main(String[] args) {

        // para gerar um vetor de 30 elementos
        int [] vetor =gerarVetor(30);
        SelecitionSort(vetor);
        // para imprimir o arrey ordenado
        System.out.println(Arrays.toString(vetor));
    }

    private static void SelecitionSort(int [] vetor) {
        for (int i = 0; i < vetor.length; i++){
            int menor =i;
            // para fazer a busca do menor elemento a partir da posiçao i mais um
            for (int j = i + 1; j < vetor.length; j++){
               if (vetor[j] < vetor[menor])
                   menor = j;
            }
            trocar (vetor, i, menor);
        }
    }
    private static void trocar(int[] vetor, int i, int menor) {
        int aux= vetor[i];
        vetor[i]= vetor[menor];
        vetor[menor]= aux;
    }
    private static int[] gerarVetor(int n) {
        int [] vetor= new int[n];
        Random gerador= new Random();
        for (int i = 0; i < n; i++){
            vetor [i] = gerador.nextInt(100);
        }
        return vetor;
    }
}
