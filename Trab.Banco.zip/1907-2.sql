use exercicio05;
select * from turma;
