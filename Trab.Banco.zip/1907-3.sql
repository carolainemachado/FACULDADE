use exercicio05;
/*1 - Faça as inserções dos seguintes alunos:*/
insert into aluno (nome,ra,endereco,telefone,RG,CPF) 
       values ('Marcos Paulo',12354,'Rua dos Eucaliptos','(51)3247-0987','8878788','1234455-90');
insert into aluno (nome,ra,endereco,telefone,RG,CPF) 
       values ('Caroline Silveira',8667,'Rua das Margaridas','(51)98765-9877','7657657','1786786-09');
insert into aluno (nome,ra,endereco,telefone,RG,CPF) 
       values ('Inácio Pena',65654,'Rua dos Marimbondos','(51)7676-87709','76576588','54675-87');
insert into aluno (nome,ra,endereco,telefone,RG,CPF) 
	   values ('Carla Farias',8987,'Rua das Gurias','(51)9865-5576','7657657','9876434-19');
       /*2 - Faça as inserções dos seguintes professores:*/
       
insert into professor (nome,num_matricula,endereco,telefone,email) 
       values ('Joana Mendes', 1223, 'Rua das Princesas','(53)98767-9770','joana.mendes@gmail.com');
insert into professor (nome,num_matricula,endereco,telefone,email) 
       values ('Flávio Canto', 4523, 'Rua dos Cangurus', '(53)87654-9087', 'flavio.cantop@hotmail.com');
       
       /*3 - Faça as inserções dos seguintes cursos:*/
insert into curso (curso,carga_horaria,professor) 
values ('Informática Básica', '60hras', 'ministrado pelo professor Flávio');
insert into curso (curso,carga_horaria,professor) 
values ('Informática Avançada', '90hras', 'ministrado pela professora Joana Mendes');

/*4 - Faça as inserções das seguintes salas:*/
insert into sala (numero,id,nome) 
	values (1,401, 'Laboratório de Info I');
insert into sala (numero,id,nome) 
	values (2,404, 'Laboratório de Info II');
insert into sala (numero,id,nome) 
	values (3,403, 'Laboratório de Info III');
    
/*5 - Os estudantes estão matriculados nos seguintes cursos:*/
insert into curso_has_aluno (aluno,curso)
	values ('Marcos Paulo',' Informática Básica');
insert into curso_has_aluno (aluno,curso)
	values ('Caroline Silveira','Informática Básica e Informática Avançada');
insert into curso_has_aluno (aluno,curso)
	values ('Inácio Pena', 'Informática Avançada');
insert into curso_has_aluno (aluno,curso)
	values ('Carla Farias','Informática Básica e Informática Avançada');
    
   /* 6 - Os cursos tem as seguintes turmas:*/
insert into turma (nome,turno,sala_id) 
	values ('Informática Básica', 'Manhã', 401);
insert into turma (nome,turno,sala_id) 
	values ('Informática Avançada', 'Noite', 403);
insert into turma (nome,turno,sala_id) 
	values ('Informática Avançada', 'Tarde', 404);
    
   /* 7 - Matricule os alunos nas suas respectivas turmas:*/
 insert into aluno_has_turma (turma,aluno,num_matricula)
	values ('Turma de informática básica manhã','Marcos Paulo in Carla Farias',333);
insert into aluno_has_turma (turma,aluno,num_matricula)
	values ('Turma de informática avançada noite','Caroline Silveira in Inácio Pena',444);
insert into aluno_has_turma (turma,aluno,num_matricula)
	values ('Turma de Informática avançada tarde','Carla Farias',555);
    
    /*8 - Atualize o e-mail do professor Flávio Canto para flavio.canto@gmail.com*/
 update professor
 set email = 'flavio.canto@gmail.com' 
 where num_matricula = 4523 ;

/*9 - Atualize a turma dos estudantes Caroline Silveira e Inácio Pena para turma de informática avançada tarde.*/
 update aluno_has_turma
 set turma = 'Turma de Informática avançada tarde' 
 where num_matricula = 444 ;
 
 /*10 - Atualize o nome das salas para Laboratório de Informática 
 I, II e III respectivamente (trocar apenas Info por Informática).*/
update sala
 set nome = 'Laboratório de Informática I'
 where id= 401;
 
update sala
set nome = 'Laboratório de Informática II'
where id= 404;

update sala
set nome = 'Laboratório de Informática III'
where id = 403;

 /*11 - Exclua a turma Turma de informática avançada noite;*/
 delete from aluno_has_turma where num_matricula = 444;
 
 /*12 - Selecione as turmas da sala 401.*/
  select *
  FROM turma
  where turno = 'Manhã'
  
 /*13 - Selecione os estudantes, as turmas e o professor do curso de informática avançada.
  select *
  FROM turma
  where nome = 'informática avançada'*/
 