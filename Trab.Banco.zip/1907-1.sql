drop database exercicio05;

create database exercicio05;
use exercicio05;
create table aluno (
   ra INT,
   nome VARCHAR(100) not null,
   endereco VARCHAR(200),
   telefone VARCHAR(15),
   email VARCHAR(200),
   rg VARCHAR(11),
   cpf VARCHAR(11) not null,
   primary key (ra)
);
create table professor (
   num_matricula INT, 
   nome VARCHAR(100) not null, 
   endereco VARCHAR(200),
   telefone VARCHAR(15), 
   email VARCHAR(200) not null,
   primary key (num_matricula)
);
create table sala (
   numero INT,
   nome varchar(100),
   id INT,
   primary key (id)
);
create table curso (
   curso varchar(100),
   carga_horaria varchar(100),
   professor VARCHAR(200)
);
create table curso_has_aluno (
   curso VARCHAR(200),
   aluno VARCHAR(200)
);
create table turma (
   nome VARCHAR(200),
   turno VARCHAR(200),
   sala_id INT not null,
   foreign key (sala_id) references sala(id)
);
create table aluno_has_turma (
   num_matricula INT,
   aluno VARCHAR(200),
   turma VARCHAR(200),
   primary key (num_matricula)
);