package Trab.Banco;

import java.sql.*;
        import java.sql.Connection;
        import java.sql.DriverManager;
        import java.sql.PreparedStatement;
        import java.sql.ResultSet;
public class Endereco {

    private int lagradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cidade;

    public int getLagradouro() {
        return lagradouro;
    }
    public void setLagradouro(int lagradouro) throws Exception{
        if (lagradouro <= 0) {
            throw new Exception ("Lagradouro deve ser um valor maior que 0!!!");
        }
        this.lagradouro = lagradouro;
    }

    public String get() {
        return bairro;
    }

    public void setBairro(String bairro) throws Exception {
        if (bairro.length() < 4) {
            throw new Exception ("O bairro deve ter no mínimo 4 caracteres!!!");
        }
        this.bairro = bairro;
    }

    public void inserir () throws Exception {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "");

            pstmt = con.prepareStatement("" +
                    "INSERT into endereco (lagradouro ,numero , complemento , bairro , cidade) " +
                    "       value (?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, this.lagradouro);
            pstmt.setString(2, this.numero);
//            System.out.println("lagrdouro" + this.lagradouro);
//            System.out.println("numero " + this.numero);
//            System.out.println("cidade " + this.cidade);
//            System.out.println("bairro " + this.bairro);
//            System.out.println("complemento " + this.complemento);
            pstmt.setString(3, this.complemento);
            pstmt.setString(4, this.bairro);
            pstmt.setString(5, this.cidade);

            // para mostrar o pstmt completa com os valores
            //System.out.println(pstmt.toString());

            pstmt.execute();

            ResultSet rs=pstmt.getGeneratedKeys();

            if(rs.next()){
                //id=rs.getInt(1);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            if (pstmt != null) pstmt.close();
            if (con != null) con.close();
        }
    }

    public void atualizar() throws Exception {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "");

            pstmt = con.prepareStatement("update endereco set lagradouro = ?, numero = ?, complemento= ?, bairro = ?, cidade = ?");
            pstmt.setInt(1, this.lagradouro);
            pstmt.setString(2, this.numero);
            pstmt.setString(3, this.complemento);
            pstmt.setString(4, this.bairro);
            pstmt.setString(5, this.cidade);

            pstmt.execute();
        } catch (Exception e) {
            throw e;
        } finally {
            if (pstmt != null) pstmt.close();
            if (con != null) con.close();
        }
    }
    public void excluir() throws Exception {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "");

            pstmt = con.prepareStatement("delete from endereco where lagradouro = ?");
            pstmt.setInt(1, this.lagradouro);

            pstmt.execute();
        } catch (Exception e) {
            throw e;
        } finally {
            if (pstmt != null) pstmt.close();
            if (con != null) con.close();
        }
    }

    public void consultar() throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "");

            pstmt = con.prepareStatement("select * from endereco");

            rs = pstmt.executeQuery();
            while (rs.next()) {
                System.out.print("Lagradouro: "+rs.getInt("lagradouro")+" - ");
                System.out.println("cidade: "+rs.getString("cidade"));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            if (pstmt != null) pstmt.close();
            if (con != null) con.close();
        }
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }
}