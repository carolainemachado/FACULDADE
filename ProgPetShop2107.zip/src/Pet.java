import java.util.ArrayList;
public class Pet {
    String especie;
    String raca;
    String nome;
    int idade;
    String cidade;

    ArrayList<Tutor> ListaTutor = new ArrayList<>();

    public Pet(String especie, String raca, String nome,int idade, String cidade) {
        this.especie = especie;
        this.raca = raca;
        this.nome = nome;
        this.idade = idade;
        this.cidade = cidade;
    }
    public void infoPets(){
        System.out.println("------- PET -------");
        System.out.println("Especie: " + this.especie);
        System.out.println("Raça: " + this.raca);
        System.out.println("Nome: "+ this.nome);
        System.out.println("Idade: " + this.idade);
        System.out.println("Cidade: "+ this.cidade + "\n");
    }

    public void addTutor(Tutor tutor){
        this.ListaTutor.add(tutor);
    }

        }
