import java.util.ArrayList;
public class Tutor extends Pessoa{

    String cidade;
    ArrayList<Pet> ListaPet = new ArrayList<>();

    public Tutor(String nome_completo, int CPF, String endereco, String email, String cidade,Integer telefones) {
        super(nome_completo, CPF, endereco, email,telefones);

        this.nome_completo=nome_completo;
        this.CPF=CPF;
        this.endereco=endereco;
        this.email=email;
        this.cidade=cidade;
    }

    public void infoTutor() {
        System.out.println("-------- TUTOR --------");
        super.infoPessoa();
        System.out.println("Cidade: " + this.cidade + "\n");
    }
        public void infoPets() {
        for (Pet pet: ListaPet){
            pet.infoPets();
            System.out.println(ListaPet);
        }
    }
}
