import java.util.ArrayList;

public class Pessoa {
    String nome_completo;
    int CPF;
    String endereco;
    String email;
    ArrayList<Integer> telefones = new ArrayList<>();

    public Pessoa(String nome_completo, int CPF, String endereco, String email,Integer telefones) {
        this.nome_completo = nome_completo;
        this.CPF = CPF;
        this.endereco = endereco;
        this.email = email;
        this.telefones.add(telefones);
    }

    public void infoPessoa() {
        System.out.println("Nome: " + this.nome_completo);
        System.out.println("CPF: " + this.CPF);
        System.out.println("Endereco: " + this.endereco);
        System.out.println("Email: " + this.email + "\n");
    }

    public void infoContato() {
        for (Integer telefones : telefones) {
                System.out.println("Telefone: " + telefones);
                //System.out.println("Listar telefones: ");
                //infoContato();


            }
        }
    }
