public class Aula2107 {

    public static void main(String[] args){

        Tutor tutor1;
        tutor1= new Tutor("Maria Oliveira",545677807,"Rua dos Andradas"
                ,"mariaoliveira@gmail.com","Alvorada",519896577);
        tutor1.infoTutor();
        tutor1.infoContato();
        tutor1.infoPets();

        Tutor tutor2;
        tutor2 = new Tutor("Amelha silveira",765594575,"Rua Dr. Flores"
                ,"amelhasilveira@gmail.com","Canoas",519657488);
        tutor2.infoTutor();
        tutor2.infoContato();

        Pet pet1;
        pet1 = new Pet("Cachorro","Pastor alemao","Billy",3,"Porto Alegre");
        pet1.infoPets();
        pet1.addTutor(tutor1);

        Pet pet2;
        pet2 = new Pet("Coelho","Coelho Rex","Mina",2,"Viamao");
        pet2.infoPets();
        pet2.addTutor(tutor2);

    }
}

