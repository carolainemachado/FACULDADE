// SUPER-CLASSE (PAI)
public class Veiculo  {
    String fabricante;
    String modelo;
    String pais;
    String posicaox;
    String posicaoy;
    String passageiros;
    String dono;
    double valor;
    String emplacar;

    public Veiculo(String fabricante, String modelo, String pais, String posicaox, String posicaoy, String passageiros, double valor) {
        this.fabricante = fabricante;
        this.modelo = modelo;
        this.pais = pais;
        this.posicaox = posicaox;
        this.posicaoy = posicaoy;
        this.passageiros = passageiros;
        this.valor = valor;
    }

    public void deslocamneto (String posicaox,String posicaoy){
        this.posicaox= posicaox;
        this.posicaoy= posicaoy;
    }

    public void info() {
        System.out.println("==============VEICULO=============== ");
        System.out.println("Fabricante: " + this.fabricante);
        System.out.println("Modelo: " + this.modelo);
        System.out.println("Pais: " + this.pais);
        System.out.println("Posicao X: " + this.posicaox);
        System.out.println("Posicao Y: " + this.posicaoy);
        System.out.println("Passageiros: " + this.passageiros);
        System.out.println("Valor: " + this.valor);

    }

    protected void compra(String dono) {
        this.dono=dono;
    }

    public void emplacamento (String emplacar){
        this.emplacar= emplacar;
    }

    public void Info() {
    }
}