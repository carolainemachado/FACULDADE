public class Moto extends VeiculoTerrestre {

    String velocidade;

    public Moto(String fabricante, String modelo, String pais, String posicaox, String posicaoy, String passageiros, double valor, String placa, String dono, String emplacar,String velocidade) {
        super(fabricante, modelo, pais, posicaox, posicaoy, passageiros, valor, placa, dono, emplacar);
        this.velocidade=velocidade;
    }

    public void info() {
        System.out.println("==========MOTO============ ");
        System.out.println("Fabricante: " + this.fabricante);
        System.out.println("Modelo: " + this.modelo);
        System.out.println("Pais: " + this.pais);
        System.out.println("Posicao X: " + this.posicaox);
        System.out.println("Posicao Y: " + this.posicaoy);
        System.out.println("Passageiros: " + this.passageiros);
        System.out.println("Valor: " + this.valor);
        System.out.println("Placa: " + this.placa);
        System.out.println("Dono: " + this.dono);
        System.out.println("Emplacamento: " + this.emplacar);
        System.out.println("Velocidade: " + this.velocidade);
    }
}
