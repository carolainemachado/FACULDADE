public class Carro extends VeiculoTerrestre {

    double combustivel;
    String classe;
    String potencia;

    public Carro(String fabricante, String modelo, String pais, String posicaox, String posicaoy, String passageiros, double valor, String placa, String dono, String emplacar,double combustivel,String classe,String potencia) {
        super(fabricante, modelo, pais, posicaox, posicaoy, passageiros, valor, placa, dono, emplacar);

        this.combustivel=combustivel;
        this.classe=classe;
        this.potencia=potencia;
    }

    public void info() {
        System.out.println("===========CARRO================");
        System.out.println("Fabricante: " + this.fabricante);
        System.out.println("Modelo: " + this.modelo);
        System.out.println("Pais: " + this.pais);
        System.out.println("Posicao X: " + this.posicaox);
        System.out.println("Posicao Y: " + this.posicaoy);
        System.out.println("Passageiros: " + this.passageiros);
        System.out.println("Valor: " + this.valor);
        System.out.println("Placa: " + this.placa);
        System.out.println("Dono: " + this.dono);
        System.out.println("Emplacamento: " + this.emplacar);
        System.out.println("Combustivel: " + this.combustivel);
        System.out.println("Classe: " + this.classe);
        System.out.println("Potencia: " + this.potencia);
    }
}
