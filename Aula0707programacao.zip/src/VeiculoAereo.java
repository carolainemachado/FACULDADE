/*
SUB-CLASSE (FILHO)
Herda os atributos e metodos de seu pai (super-classe)
 */
public class VeiculoAereo extends Veiculo {

    String codigo;
    String empresa;
    String posicaoz;
    String dono; // =compra

    public VeiculoAereo(String fabricante, String modelo, String pais, String posicaox, String posicaoy, double valor,String passageiros, String codigo,String posicaoz, String empresa,String dono) {
        super(fabricante, modelo, pais, posicaox, posicaoy, passageiros, valor);
        this.codigo = codigo;
        this.empresa = empresa;
        this.posicaoz = posicaoz;
        this.dono= dono;
    }

    @Override
    public void info(){
        System.out.println("============VEICULO AEREO=============== ");
        System.out.println("Fabricante: " + this.fabricante);
        System.out.println("Modelo: " + this.modelo);
        System.out.println("Pais: " + this.pais);
        System.out.println("Posicao X: " + this.posicaox);
        System.out.println("Posicao Y: " + this.posicaoy);
        System.out.println("Passageiros: " + this.passageiros);
        System.out.println("Valor: " + this.valor);
        System.out.println("Codigo: " + this.codigo);
        System.out.println("Empresa: " + this.empresa);
        System.out.println("Posicao Z: " + this.posicaoz);
        System.out.println("Compra: " + this.dono);

    }

    @Override
    public void deslocamneto(String posicaox, String posicaoy) {
        super.deslocamneto(posicaox, posicaoy);
    }

    public void compra (String dono){
        super.compra(dono);

    }
}
