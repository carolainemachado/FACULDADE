public class Helicoptero extends VeiculoAereo {

    String rotor;

    public Helicoptero(String fabricante, String modelo, String pais, String posicaox, String posicaoy, double valor, String passageiros, String codigo, String posicaoz, String empresa, String dono, String rotor) {
            super(fabricante, modelo, pais, posicaox, posicaoy, valor, passageiros, codigo, posicaoz, empresa, dono);
            this.rotor=rotor;
        }

    public void info() {
        System.out.println("============HELICOPTERO=============== ");
        System.out.println("Fabricante: " + this.fabricante);
        System.out.println("Modelo: " + this.modelo);
        System.out.println("Pais: " + this.pais);
        System.out.println("Posicao X: " + this.posicaox);
        System.out.println("Posicao Y: " + this.posicaoy);
        System.out.println("Passageiros: " + this.passageiros);
        System.out.println("Valor: " + this.valor);
        System.out.println("Codigo: " + this.codigo);
        System.out.println("Empresa: " + this.empresa);
        System.out.println("Posicao Z: " + this.posicaoz);
        System.out.println("Compra: " + this.dono);
        System.out.println("Rotor: " + this.rotor);

        }
    }


