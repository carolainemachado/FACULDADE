public class VeiculoMarinho extends Veiculo {
    String codigo;
    String empresa;
    String dono; // =compra

    public VeiculoMarinho(String fabricante, String modelo, String pais, String posicaox, String posicaoy, String passageiros, double valor, String codigo, String empresa,String dono) {
        super(fabricante, modelo, pais, posicaox, posicaoy, passageiros, valor);
        this.codigo = codigo;
        this.empresa = empresa;
        this.dono= dono;
    }

    public void info() {
        System.out.println("==============VEICULO MARINHO==================");
        System.out.println("Fabricante: " + this.fabricante);
        System.out.println("Modelo: " + this.modelo);
        System.out.println("Pais: " + this.pais);
        System.out.println("Posicao X: " + this.posicaox);
        System.out.println("Posicao Y: " + this.posicaoy);
        System.out.println("Passageiros: " + this.passageiros);
        System.out.println("Valor: " + this.valor);
        System.out.println("Codigo: " + this.codigo);
        System.out.println("Empresa: " + this.empresa);
        System.out.println("Compra: " + this.dono);
    }

    public void compra (String dono){
        super.compra(dono);

    }
}