public class Aviao extends VeiculoAereo {

        String cor;

    public Aviao(String fabricante, String modelo, String pais, String posicaox, String posicaoy, double valor, String passageiros, String codigo, String posicaoz, String empresa, String dono,String cor) {
        super(fabricante, modelo, pais, posicaox, posicaoy, valor, passageiros, codigo, posicaoz, empresa, dono);
        this.cor = cor;
    }

    public void info() {
        System.out.println("===============AVIAO============== ");
        System.out.println("Fabricante: " + this.fabricante);
        System.out.println("Modelo: " + this.modelo);
        System.out.println("Pais: " + this.pais);
        System.out.println("Posicao X: " + this.posicaox);
        System.out.println("Posicao Y: " + this.posicaoy);
        System.out.println("Passageiros: " + this.passageiros);
        System.out.println("Valor: " + this.valor);
        System.out.println("Codigo: " + this.codigo);
        System.out.println("Empresa: " + this.empresa);
        System.out.println("Posicao Z: " + this.posicaoz);
        System.out.println("Compra: " + this.dono);
        System.out.println("Cor: " + this.cor);
        }
    }
