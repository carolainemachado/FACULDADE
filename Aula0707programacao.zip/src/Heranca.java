import java.util.ArrayList;
import java.util.Scanner;

    interface aula07072022{
        public static void main(String[] args) {

            ArrayList<Veiculo> v = new ArrayList<Veiculo>();
            Scanner teclado = new Scanner(System.in);

            Veiculo v1;
            v1 = new Veiculo("Fiat","Argo","Italia","15","30","4",70.000);
            v1.info();
            v.add(v1);

            VeiculoAereo v2 ;
            v2 = new VeiculoAereo("AEROMOT ","monomotores","China","50","15",500.000,
                    "50","6743959697","56","LATAM Airlines Group SA","Marcela");
            v2.info();
            v.add(v2);

            Aviao v3 ;
            v3 = new Aviao("Indústria Aeronáutica Neiva","Eletricidade","EUA","67","43",600.000,
                    "45","7978321","23","LATAM Airlines","Bruna","Azul");
            v3.info();
            v.add(v3);

            Helicoptero v4;
            v4 = new Helicoptero ("Helibras","EC725","Brasil","12","09",400.000,
                    "40","784722","34","Airbus Helicopters","Eva","Simples");
            v4.info();
            v.add(v4);

            VeiculoMarinho v5;
            v5 = new VeiculoMarinho("Sessa Marine","C40","Italia","32","49","10",
                    345.000,"654788","Intech Boating","Marcio");
            v5.info();
            v.add(v5);

            Navio v6;
            v6 = new Navio("Brodosplit Shipyard","C56","China","98","21","11",380.000,
                    "909122","Disney Cruise Line","Wania","Bruni");
            v6.info();
            v.add(v6);

            Submarino v7;
            v7 = new Submarino("PROSUB ","585844","EUA","80","13","3",900.000,
                    "8978681","Comércio eletrônico","Maria","78",10.934);
            v7.info();
            v.add(v7);

            VeiculoTerrestre v8;
            v8 = new VeiculoTerrestre("Ford","Fiesta","EUA","51","32","4",30.000,
                    "7473","Carmen","46766363");
            v8.info();
            v.add(v8);

            Carro v9;
            v9 = new Carro("Hyundai","HB20","China","43","78","3",60.000,
                    "7684","Riani","8970786",8,"Novo","60");
            v9.info();
            v.add(v9);

            Caminhao v10;
            v10 = new Caminhao("Mercedes-Benz","LP 321","Alemanha","23","56","2",59.578,
                    "5748390","Helena","23467","2",6.000,"6 toneladas","6 toneladas");
            v10.info();
            v.add(v10);

            Moto v11;
            v11 = new Moto("Moto Honda","Honda","Manaus","81","12","2",20.000,
                    "6352","Davi","546369","120");
            v11.info();
            v.add(v11);
            
        }

    }



