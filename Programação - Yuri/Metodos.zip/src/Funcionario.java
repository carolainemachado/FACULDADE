public class Funcionario {

    String Nome, cargo;
    double salario;

    public Funcionario(String nome, double cargo, String salario) {

        this.Nome=nome;
        this.salario= 2500;
        this.cargo= "Sub gerente";
        this.Info();
    }
    public void Info(){
        System.out.println("===== Informaçoes do Funcionario =====");
        System.out.println("Nome do funcionario: " + this.Nome);
        System.out.println("Salario: " + this.salario);
        System.out.println("cargo: " + this.cargo);
    }
    public void Novosalario(double salario) {
        this.salario = salario ;
        System.out.println("Novo salario: " + salario);
    }
    public void Novocargo(String cargo) {
        this.cargo = cargo;
        System.out.println("Nova cargo: " + cargo);
    }
}