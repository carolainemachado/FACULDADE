public class Metodos {
    public static void main(String[] args) {

        Empresa empresa1;
        empresa1= new Empresa("ASJ","0987654789000","Rua Alberto Hoffmann");
        empresa1.NovoEndereço("Rua Borges de medeiros 165");
        empresa1.Info();

        System.out.println("-------------------------------------"+"\n");

        Remedio remedio1;
        remedio1= new Remedio("Paracetamol",15,100);

        remedio1.NovoValor(40);
        remedio1.NovoEstoque(150);
        remedio1.Incremento(10);
        remedio1.Decrementa(-30);
        remedio1.Info();

        System.out.println("-------------------------------------"+"\n");


        Livro livro1;
        livro1 = new Livro("A culpa e das estrlas",40,200);
        livro1.NovoValor(70);
        livro1.NovoEstoque(150);
        livro1.Incremento(15);
        livro1.Decrementa(-10);
        livro1.Info();
        System.out.println("-------------------------------------"+"\n");

        Funcionario funcionario1;
        funcionario1= new Funcionario("Lorenzo",2500,"Sub gerente");
        funcionario1.Novosalario(3000);
        funcionario1.Novocargo("Gerente");
        remedio1.Info();
        System.out.println("-------------------------------------"+"\n");
    }
}
