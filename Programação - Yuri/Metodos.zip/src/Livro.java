public class Livro {
    String Nome;
    int Valor, Estoque;

    public Livro(String nome,int Valor,int Estoque) {

        this.Nome=nome;
        this.Valor= 50;
        this.Estoque= 200;
        this.Info();
    }
    public void Info () {
        System.out.println("===== Informaçoes do Livro =====");
        System.out.println("Nome do livro: " + this.Nome);
        System.out.println("Valor: " + this.Valor);
        System.out.println("Estoque: " + this.Estoque);
    }
    public void NovoValor(int valor) {
        this.Valor = valor;
        System.out.println("Novo valor: " + this.Valor);
    }
    public void NovoEstoque(int estoque) {
        this.Estoque = estoque;
        System.out.println("Novo estoque: " + this.Estoque);
    }
    public void Incremento(int Incremento) {
        this.Estoque = this.Estoque + Incremento;
        System.out.println("Incremento: " + Incremento);
    }
    public void Decrementa(int Decrementa) {
        this.Estoque = this.Estoque + Decrementa;
        System.out.println("Decrementa: " + Decrementa);
    }
}
