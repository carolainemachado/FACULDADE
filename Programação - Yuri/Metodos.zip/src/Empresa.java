public class Empresa {
    String Nome, CNPJ, Endereço;

    public Empresa(String nome,String CNPJ,String Endereço) {

        this.Nome=nome;
        this.CNPJ= CNPJ;
        this.Endereço= Endereço;
        this.Info();

    }
        public void Info(){
        System.out.println("===== Informaçoes da Empresa =====");
        System.out.println("Nome da empresa: " + this.Nome);
        System.out.println("CNPJ: " + this.CNPJ);
        System.out.println("Endereço: " + this.Endereço);
    }

    public void NovoEndereço(String Endereço) {
        this.Endereço = Endereço;

    }

}