public class Conta {
    //definiçao dos atributos
    String nome;
    String cpf;
    private double saldo;
    public void info () {

        System.out.println("Nome: " + this.nome);
        System.out.println("CPF : " + this.cpf);
        System.out.println("Saldo : " + this.getSaldo());
    }
    // get em minusculo e o nome do atributo em letra maiuscula
    // ()para indicar que nao recebe nem um paramentro

    public double getSaldo() {
        return saldo;
    }

    // set para alterar o valor do saldo ele nao retorna nada

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}

