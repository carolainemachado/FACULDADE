public class Encapsulamento {
    public static void main(String[] args) {

        //instanciando um obj na memoria do tipo conta
        Conta c1;
        c1= new Conta();

        c1.nome= "Aline";
        c1.cpf= "098765478900";
        c1.setSaldo(900.00);

        c1.info();
        System.out.println("---------------------");
    }
}

// encapisulamento e um recurso para controlar o acesso de alguns dados
// ex se deixar o saldo como pulic eu posso mudar o valor livremente
// get significa obter
// set significa definir

