public class Empresa {
    String Nome, CNPJ, Endereço, Serviço;

    public void info () {
        System.out.println("Nome da empresa: " + this.Nome);
        System.out.println("CNPJ : " + this.CNPJ);
        System.out.println("Endereço : " + this.Endereço);
        System.out.println("Serviço : " + this.Serviço);


    }
}
