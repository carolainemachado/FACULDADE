public class Livro {
    String Titulo, ISBN,Valor, Autor, Editora, Estoque;

    public void info () {

        System.out.println("Titulo do livro: " + this.Titulo);
        System.out.println("ISBN : " + this.ISBN);
        System.out.println("Valor : " + this.Valor);
        System.out.println("Autor : " + this.Autor);
        System.out.println("Editoras : " + this.Editora);
        System.out.println("Estoque: " + this.Estoque);
   }
}
