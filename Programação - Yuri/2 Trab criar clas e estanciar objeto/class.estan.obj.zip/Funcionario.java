public class Funcionario {

    String Nome, Sobrenome,CPF, Salario, Cargo;

    public void info () {

        System.out.println("Nome do/da funcionario: " + this.Nome);
        System.out.println("Sobrenome : " + this.Sobrenome);
        System.out.println("CPF : " + this.CPF);
        System.out.println("Salario : " + this.Salario);
        System.out.println("Cargo : " + this.Cargo);

    }
}