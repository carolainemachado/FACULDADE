package Remedio;

public class Remedio {

    public String Nome;
}
