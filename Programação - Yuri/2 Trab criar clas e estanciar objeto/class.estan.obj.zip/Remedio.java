public class Remedio {

        String Nome, Tarja, Laboratorio;
        int Valor, Estoque;
        public void info () {
            System.out.println("Nome do remedio: " + this.Nome);
            System.out.println("Tarja : " + this.Tarja);
            System.out.println("Valor : " + this.Valor);
            System.out.println("Laboratorio : " + this.Laboratorio);
            System.out.println("Estoque : " + this.Estoque);
        }
    }


