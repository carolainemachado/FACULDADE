
public class Programa1 {
    public static void main(String[] args) {

        Empresa empresa1;
        empresa1= new Empresa();

        empresa1.Nome= "ASJ";
        empresa1.CNPJ= "0987654789000";
        empresa1.Endereço= "Rua Alberto Hoffmann";
        empresa1.Serviço="Associaçao";

        empresa1.info();
        System.out.println("---------------------");

        Remedio remedio1;
        remedio1= new Remedio();

        remedio1.Nome= "Paracetamol";
        remedio1.Tarja= "Vermelha";
        remedio1.Valor= 15;
        remedio1.Laboratorio="Globo 750mg";
        remedio1.Estoque= 30;

        remedio1.info();
        System.out.println("---------------------");

        Livro livro1;
        livro1= new Livro();

        livro1.Titulo= "A culpa e das estrelas";
        livro1.ISBN= "8580573807";
        livro1.Valor="40";
        livro1.Editora="Intrínseca";
        livro1.Estoque= "50";

        livro1.info();
        System.out.println("---------------------");

        Funcionario funcionario1;
        funcionario1= new Funcionario();

        funcionario1.Nome= "Vanessa";
        funcionario1.Sobrenome= "Barbosa";
        funcionario1.CPF="2685844092345";
        funcionario1.Salario="2000";
        funcionario1.Cargo= "Auxiliar ADM";

        funcionario1.info();

        System.out.println("---------------------");
    }
}
