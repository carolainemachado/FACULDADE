public class Programa1 {
    public static void main(String[] args) {

        Funcionarios funcionario1;
        funcionario1= new Funcionarios();

        funcionario1.nome= "Carolaine";
        funcionario1.sobrenome= "Machado";
        funcionario1.cpf= "0987654789000";
        funcionario1.idade= 21;
        funcionario1.funçao="Auxiliar ADM";

        funcionario1.info();

    }
}
