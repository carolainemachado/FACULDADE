public class Funcionarios {
    String nome, sobrenome, cpf, funçao;
    int idade;

    public void info () {
        System.out.println("Meu nome e: " + this.nome);
        System.out.println("Meu sobrenome e: " + this.sobrenome);
        System.out.println("Meu cpf e: " + this.cpf);
        System.out.println("Minha idade e: " + this.idade);
        System.out.println("Minha funçao e: " + this.funçao);
    }
}