import java.util.ArrayList;
public class Tutor extends Pessoa {

    String nome_completo;
    int CPF;
    String endereco;
    String email;
    int listatelefone;
    String cidade;
    ArrayList<Pets> listapets = new ArrayList();

    public Tutor(String nome_completo, int CPF, String endereco, String email, int listatelefone,String cidade) {
        super(nome_completo, CPF, endereco, email, listatelefone);
        this.nome_completo = nome_completo;
        this.CPF=CPF;
        this.endereco=endereco;
        this.email=email;
        this.listatelefone =listatelefone;
        this.cidade=cidade;
    }
    public void infoTutor(){
        System.out.println("----------- TUTOR ------------");
        super.infoPessoa();
        System.out.println("Cidade: " + this.cidade + "\n");
    }
    public void infoPets(){
        for (Pets pets:listapets){
                pets.infoPet();
            System.out.println(listapets);
        }
    }
}
