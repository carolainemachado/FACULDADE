import java.util.ArrayList;

public class Pessoa {
    private String nome_completo;
    private int CPF;
    private String endereco;
    private String email;
    private int telefone;

    ArrayList<Integer> listatelefone = new ArrayList();

    public Pessoa(String nome_completo, int CPF, String endereco, String email, int listatelefone) {
        this.nome_completo = nome_completo;
        this.CPF = CPF;
        this.endereco = endereco;
        this.email = email;
        this.listatelefone.add(listatelefone);
    }
    public void infoPessoa(){
        System.out.println("Nome completo: " + this.nome_completo);
        System.out.println("CPF:" + this.CPF);
        System.out.println("Endereço: " + this.endereco);
        System.out.println("E-mail: " + this.email );
    }
    public void infoContato(){
        for (Integer listatelefone: listatelefone){
            System.out.println("----------- CONTATO ------------");
            System.out.println("Telefone: " + this.listatelefone + "\n");
        }
    }
}
