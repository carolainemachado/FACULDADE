public class PetShopV2 {
    public static void main(String []args){

        Tutor tutor1;
        tutor1 =new Tutor("Marcos da Silva Castro",68575650,"Rua Borges de Medeiros"
                ,"marcoscastro@gmail.com",519856539,"Porto Alegre");
        tutor1.infoTutor();
        tutor1.infoContato();
        tutor1.infoPets();

        Veterinario veterinario1;
        veterinario1 = new Veterinario("Wander de Lima",767090765,"Rua Dr. Flores"
                ,"wanderlima@gmail.com",519865457,444,"Tarde");

        veterinario1.infoConsultas();
        Pets pets1;
        pets1 = new Pets("Cachorro","Labrador","Bobi",3);
        pets1.infoPet();
        pets1.addTutor(tutor1);
        //pets1.addConsulta(consulta1);

        Consulta consulta1;
        consulta1 = new Consulta(veterinario1,pets1,tutor1
                ,70.00,"23/07/2022");
        consulta1.infoConsulta();










    }
}
