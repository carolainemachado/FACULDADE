import java.util.ArrayList;
public class Veterinario extends Pessoa{

    int CRMV;
    String turno;

    ArrayList<Consulta> listaconsultas = new ArrayList();
    public Veterinario(String nome_completo, int CPF, String endereco, String email, int listatelefone,int CRMV, String turno) {
        super(nome_completo, CPF, endereco, email, listatelefone);

        this.CRMV = CRMV;
        this.turno = turno;
    }
    public void infoVeterinario(){
        System.out.println("---------- VETERINARIO ----------");
        super.infoPessoa();
        System.out.println("CRMV " + this.CRMV);
        System.out.println("Turno: " + this.turno + "\n");
    }
    public void infoConsultas(){
        for (Consulta consulta:listaconsultas){
             consulta.infoConsulta();
            System.out.println(listaconsultas);
        }
    }
}
