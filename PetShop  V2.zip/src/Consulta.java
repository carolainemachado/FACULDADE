public class Consulta {
    Veterinario veterinario;
    Pets pets;
    Tutor acompanhante;
    double valor;
    String data;

    public Consulta(Veterinario veterinario, Pets pets, Tutor acompanhante, double valor, String data) {
        this.veterinario = veterinario;
        this.pets = pets;
        this.acompanhante = acompanhante;
        this.valor = valor;
        this.data = data;
    }

    public void infoConsulta(){
        System.out.println("----------- CONSULTA -------------");
        System.out.println("Valor: " + this.valor);
        System.out.println("Data: " + this.data + "\n");
        veterinario.infoVeterinario();
    }
}
