import java.util.ArrayList;
public class Pets {
    private String especie;
    private String raca;
    private String nome;
    private int idade;

    private ArrayList<Tutor> listaTutor= new ArrayList();
    public ArrayList<Consulta> listaconsultas = new ArrayList();

    public Pets(String especie, String raca, String nome, int idade) {
        this.especie = especie;
        this.raca = raca;
        this.nome = nome;
        this.idade = idade;
    }
    public void infoPet(){
        System.out.println("-------------- PET --------------");
        System.out.println("Especie: " + this.especie);
        System.out.println("Raça: " + this.raca);
        System.out.println("Nome: " + this.nome);
        System.out.println("Idade: " + this.idade + "\n");
    }
    public void addTutor (Tutor tutor){
        this.listaTutor.add(tutor);
    }
   public void addConsulta (Consulta consulta){
        this.listaconsultas.add(consulta);
   }
}
