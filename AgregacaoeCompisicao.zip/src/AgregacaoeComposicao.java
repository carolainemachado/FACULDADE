public class AgregacaoeComposicao {
public static void main(String[]args){

    Empresa e1;
    e1 = new Empresa("Miranda Moveis","Miranda LTDA","7474599980");
    e1.info();

    Funcionario f1;
    f1 =new Funcionario("Maria","Comercial","456" ,e1);
    f1.info();
    f1.AdicionarFuncionario(f1);

    Funcionario f2;
    f2 =new Funcionario("Angelo","Assistencia","985" ,e1);
    f2.info();
    f2.AdicionarFuncionario(f2);

  }
}
