public class Empresa {
    String nome;
    String razaoSocial;
    String CNPJ;


    public Empresa(String nome, String razaoSocial, String CNPJ) {
        this.nome = nome;
        this.razaoSocial = razaoSocial;
        this.CNPJ = CNPJ;
    }

    public void info(){
        System.out.println("====== INFO DA EMPRESA =======");
        System.out.println("Nome: " + this.nome);
        System.out.println("Razao Social: " + this.razaoSocial);
        System.out.println("CNPJ: " + this.CNPJ);
        System.out.println("\n");
    }
}
