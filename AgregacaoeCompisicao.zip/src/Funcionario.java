import java.util.ArrayList;

public class Funcionario {
    String nome;
    String setor;
    String codigo;
    Empresa Empresatitular;

    ArrayList<Funcionario> ListadeFuncionarios = new ArrayList<>();

    public Funcionario(String nome, String setor, String codigo, Empresa emp) {
        this.nome = nome;
        this.setor = setor;
        this.codigo = codigo;
        this.Empresatitular = emp;
    }

    public void info(){
        System.out.println("++++ INFO DO FUNCIONARIO");
        System.out.println("Nome: " + this.nome);
        System.out.println("Setor: " + this.setor);
        System.out.println("Codigo: " + this.codigo);
        System.out.println("Empresa Titular: " + this.Empresatitular + "\n");
    }

    public void AdicionarFuncionario(Funcionario NovoFuncionario){
        this.ListadeFuncionarios.add(NovoFuncionario);
        System.out.println("Funcionario Cadastrado");
    }

}
